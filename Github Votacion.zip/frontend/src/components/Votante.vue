<template>
<div class='votantes'>  
    <b-table striped hover 
        responsive="sm"
        :items="votantes">
        
        <template #cell(actions)="row" >
            <b-button variant="danger" size="sm" @click="deleteTask(row.item)" class="mr-2">
                Remove
            </b-button>
        </template>
    </b-table>   

   <h2>Votantes</h2>
    <b-form inline @submit="addTask">
        <label class="sr-only" for="inline-form-input-name">DNI Votante</label>
        <b-form-input v-model='newTask.dnivotante'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="DNI"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-name">N° Sala</label>
        <b-form-input v-model='newTask.numerosala'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="N° Sala"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">N° Mesa</label>
        <b-form-input v-model='newTask.numeromesa'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="N° Mesa"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">N° Orden</label>
        <b-form-input v-model='newTask.numeroorden'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="N° Orden"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Local de votacion</label>
        <b-form-input v-model='newTask.localdevotacion'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Local de votacion"
        ></b-form-input>

        <!-- <label class="sr-only" for="inline-form-input-username">Foto del votante</label>
        <b-form-input v-model='newTask.votantefoto'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Foto del votante"
        ></b-form-input> -->

        <label>Subir Imagen
            <input type="file" id="file" ref="file" v-on:change="onChangeFileUpload()"/>
        </label>
        <br>  
        <b-button b-button type="submit" variant="primary" v-on:click="onChangeFileUpload()">Submit</b-button>

        <!-- <br>        
        <b-button type="submit" variant="primary">Submit</b-button> -->
    </b-form>

    <!-- <div id="container">
      <video autoplay="true" id="videoElement"> 
    </video>  
    </div>
    
    <button variant="primary" v-on:click='open'> Open </button>
    <button variant="primary" v-on:click='stop'> Stop </button>
    <button variant="primary" id="snap" v-on:click='snap'>Snap Photo</button>
    <br>

    <canvas id="canvas" width="500px" height="375px"></canvas> -->
</div>
</template>

<script>
import axios from 'axios'
export default{    
    data(){ 
        return {
            file: '',          
            votantes: [],
            newTask: {},
            postURL: 'http://127.0.0.1:5000',
            config_request: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            my_video: {}           
        }
    },
    methods:{
        addTask(event){ 
            event.preventDefault();
            console.log("Votante añadido");
            axios.post(this.postURL + '/create_votante', this.newTask, this.config_request)
                .then(res => {
                    // this.tasks(res.data);                                         
                    console.log(res.data);
                    // var id_votante = res.data["id"];
                    var dni_votante = res.data["dnivotante"];
                    var imagen_file = this.file;
                    // console.log(id_votante);
                    // console.log(imagen_file);
                    // console.log(typeof(dni_votante));

                    // VECTOR DE CARACTERISTICAS

                    let formVector = new FormData();
                    formVector.append('image', this.file);
          
                    this.axios.post('http://192.168.99.100:81/receive_image',
                        formVector,
                        {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                      }
                    ).then(function(dataVF){
                      console.log(dataVF.data);
                      var vector_imagen_votante = dataVF.data;
                      console.log(vector_imagen_votante);

                      // Subir Imagen

                        let formData = new FormData();
                        formData.append('file', imagen_file);
                        // formData.append('id_votante', id_votante);
                        formData.append('dni_votante', dni_votante);
                        formData.append('vector_imagen_votante', vector_imagen_votante);
              
                        axios.post('http://localhost:5000/upload_votante',
                            formData,
                            {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                          }
                        ).then(function(data){
                          console.log(data.data);
                        })
                        .catch(function(){
                          console.log('NO SE SUBIO LA IMAGEN!!');
                        });

                    })
                    // .catch(function(){
                    //   console.log('NO SE OBTUVO EL VECTOR!!');
                    // });

                    .catch((error) => {
                    console.log(error)
                        });

                })
                .catch((error) => {
                    console.log(error)
                });

            // Subir Imagen

            // let formData = new FormData();
            // formData.append('file', this.file);
  
            // this.axios.post('http://localhost:5000/',
            //     formData,
            //     {
            //     headers: {
            //         'Content-Type': 'multipart/form-data'
            //     }
            //   }
            // ).then(function(data){
            //   console.log(data.data);
            // })
            // .catch(function(){
            //   console.log('NO SE SUBIO LA IMAGEN!!');
            // });

            // // Vector de caracteristicas

            // let formVector = new FormData();
            // formVector.append('image', this.file);
  
            // this.axios.post('http://192.168.99.100:81/receive_image',
            //     formVector,
            //     {
            //     headers: {
            //         'Content-Type': 'multipart/form-data'
            //     }
            //   }
            // ).then(function(dataOF){
            //   console.log(dataOF.data);
            // })
            // .catch(function(){
            //   console.log('NO SE OBTUVO EL VECTOR!!');
            // });


            this.newTask = {};
        },
        deleteTask(task){  
            console.log(task);
                               
            axios.post(this.postURL + '/task/delete_task', {id:task.id}, this.config_request)
                .then(res => {                      
                    this.tasks.splice(this.tasks.indexOf(task), 1);                    
                })
                .catch((error) => {
                    console.log(error)
                });  
        },
      //   submitForm(){
      //       let formData = new FormData();
      //       formData.append('file', this.file);
  
      //       this.axios.post('http://localhost:5000/',
      //           formData,
      //           {
      //           headers: {
      //               'Content-Type': 'multipart/form-data'
      //           }
      //         }
      //       ).then(function(data){
      //         console.log(data.data);
      //       })
      //       .catch(function(){
      //         console.log('FAILURE!!');
      //       });
      // },
  
      onChangeFileUpload(){
        this.file = this.$refs.file.files[0];
      },
      // stop(e) {
      //       //var stream = this.my_video.srcObject;
            
      //       var stream = document.querySelector("#videoElement").srcObject;
      //       var tracks = stream.getTracks();

      //       for (var i = 0; i < tracks.length; i++) {
      //         var track = tracks[i];
      //         track.stop();
      //       }

      //       //this.video.srcObject = null;
      //       document.querySelector("#videoElement").srcObject = null
      //     },
      // open() {
      //     this.my_video = document.querySelector("#videoElement");          

      //     console.log(this.my_video);

      //     if (navigator.mediaDevices.getUserMedia) {
      //       navigator.mediaDevices.getUserMedia({ video: true })
      //         .then(function (stream) {
      //           console.log(stream);
      //           //this.my_video.srcObject = stream;
      //           document.querySelector("#videoElement").srcObject = stream;
      //         })
      //         .catch(function (err) {
      //           console.log("Something went wrong!");
      //           console.log(err);
      //         });
      //     }
      //   },
      //   snap(){
      //     var video=document.querySelector('video');
      //     var canvas = document.querySelector('canvas');
      //     var context = canvas.getContext('2d');
          

      //     var ratio = video.videoWidth/video.videoHeight;
      //     var w = video.videoWidth-100;
      //     var h = parseInt(w/ratio,10);
      //     canvas.width = w;
      //     canvas.height = h;

      //     context.fillRect(0,0,w,h);
      //     context.drawImage(document.querySelector('video'),0,0,w,h);   
                
      //   }
    }

}
</script>

<style>
</style>