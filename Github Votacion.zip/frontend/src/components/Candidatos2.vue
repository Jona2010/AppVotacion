<template>
<div class='tasks'>  
    <b-table striped hover 
        responsive="sm"
        :items="tasks" 
        :fields="fields">
        
        <template #cell(actions)="row" >
            <b-button variant="danger" size="sm" @click="deleteTask(row.item)" class="mr-2">
                Remove
            </b-button>
        </template>
    </b-table>   

   <h2>Candidatos</h2>
    <b-form inline @submit="addTask">
        <label class="sr-only" for="inline-form-input-name">Partido</label>
        <b-form-input v-model='newTask.candidatepartido'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Partido"
        ></b-form-input>

        <!-- <label class="sr-only" for="inline-form-input-username">Ruta Imagen</label>
        <b-form-input v-model='newTask.candidateimagen'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Ruta Imagen"
        ></b-form-input> -->


        <label class="sr-only" for="inline-form-input-username">Ocupacion</label>
        <b-form-input v-model='newTask.candidateocupacion'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Ocupacion"
        ></b-form-input> 

        <label class="sr-only" for="inline-form-input-username">Sentencias</label>
        <b-form-input v-model='newTask.candidatesentencias'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Sentencias"
        ></b-form-input>

        <label>Subir Imagen
            <input type="file" id="file" ref="file"/>
        </label>
        <br>  
        <b-button b-button type="submit" variant="primary" v-on:click="onChangeFileUpload()">Submit</b-button>

        <!-- 
        <br>      
        <b-button type="submit" variant="primary">Submit</b-button> -->
    </b-form>
    
</div>
</template>

<script>
import axios from 'axios'
export default{
    data(){ 
        return {
            file: '',
            fields: [
                
            ],            
            tasks: [],
            newTask: {},
            postURL: 'http://127.0.0.1:5000',
            config_request: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },         
        }
    },
    methods:{
        addTask(event){ 
            event.preventDefault();
            console.log("Candidato añadido");
            axios.post(this.postURL + '/create_candidate', this.newTask, this.config_request)
                .then(res => {
                    // this.tasks(res.data);                                         
                    console.log(res.data);
                    var id_candidato = res.data["id"];
                    var imagen_file = this.file;
                    console.log(id_candidato);

                    // VECTOR DE CARACTERISTICAS

                    let formVector = new FormData();
                    formVector.append('image', this.file);
          
                    this.axios.post('http://192.168.99.100:81/receive_image',
                        formVector,
                        {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                      }
                    ).then(function(dataOF){
                      console.log(dataOF.data);
                      var vector_imagen = dataOF.data;
                      console.log(vector_imagen);

                      // Subir Imagen

                        let formData = new FormData();
                        formData.append('file', imagen_file);
                        formData.append('id_candidato', id_candidato);
                        formData.append('vector_imagen', vector_imagen);
              
                        axios.post('http://localhost:5000/',
                            formData,
                            {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                          }
                        ).then(function(data){
                          console.log(data.data);
                        })
                        .catch(function(){
                          console.log('NO SE SUBIO LA IMAGEN!!');
                        });

                    })
                    // .catch(function(){
                    //   console.log('NO SE OBTUVO EL VECTOR!!');
                    // });

                    .catch((error) => {
                    console.log(error)
                        });

                })
                .catch((error) => {
                    console.log(error)
                });

            // Subir Imagen

            // let formData = new FormData();
            // formData.append('file', this.file);
  
            // this.axios.post('http://localhost:5000/',
            //     formData,
            //     {
            //     headers: {
            //         'Content-Type': 'multipart/form-data'
            //     }
            //   }
            // ).then(function(data){
            //   console.log(data.data);
            // })
            // .catch(function(){
            //   console.log('NO SE SUBIO LA IMAGEN!!');
            // });

            // // Vector de caracteristicas

            // let formVector = new FormData();
            // formVector.append('image', this.file);
  
            // this.axios.post('http://192.168.99.100:81/receive_image',
            //     formVector,
            //     {
            //     headers: {
            //         'Content-Type': 'multipart/form-data'
            //     }
            //   }
            // ).then(function(dataOF){
            //   console.log(dataOF.data);
            // })
            // .catch(function(){
            //   console.log('NO SE OBTUVO EL VECTOR!!');
            // });


            this.newTask = {};
        },
        deleteTask(task){  
            console.log(task);
                               
            axios.post(this.postURL + '/task/delete_task', {id:task.id}, this.config_request)
                .then(res => {                      
                    this.tasks.splice(this.tasks.indexOf(task), 1);                    
                })
                .catch((error) => {
                    console.log(error)
                });  
        },
      //   submitForm(){
      //       let formData = new FormData();
      //       formData.append('file', this.file);
  
      //       this.axios.post('http://localhost:5000/',
      //           formData,
      //           {
      //           headers: {
      //               'Content-Type': 'multipart/form-data'
      //           }
      //         }
      //       ).then(function(data){
      //         console.log(data.data);
      //       })
      //       .catch(function(){
      //         console.log('FAILURE!!');
      //       });
      // },
  
      onChangeFileUpload(){
        this.file = this.$refs.file.files[0];
      }
    //   onChangeFileUpload: function (mensaje) {
    //   alert(mensaje)
    // }
    }
}
</script>

<style>   
</style>