<template>
<div class='tasks'>  
    <b-table striped hover 
        responsive="sm"
        :items="tasks" 
        :fields="fields">
        
        <template #cell(actions)="row" >
            <b-button variant="danger" size="sm" @click="deleteTask(row.item)" class="mr-2">
                Remove
            </b-button>
        </template>
    </b-table>   

   <h2>Usuarios</h2>
    <b-form inline @submit="addTask">
        <label class="sr-only" for="inline-form-input-name">Nombre</label>
        <b-form-input v-model='newTask.usuarionombre'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Nombre"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Apellidos</label>
        <b-form-input v-model='newTask.usuarioapellidos'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Apellidos"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">DNI</label>
        <b-form-input v-model='newTask.usuariodni'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="DNI"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Direccion</label>
        <b-form-input v-model='newTask.usuariodireccion'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Direccion"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Edad</label>
        <b-form-input v-model='newTask.usuarioedad'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Edad"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Fecha Nacimiento</label>
        <b-form-datepicker v-model='newTask.usuariofechanacimiento'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Fecha Nacimiento"
        ></b-form-datepicker>

        <label class="sr-only" for="inline-form-input-username">DNI Emision</label>
        <b-form-datepicker v-model='newTask.usuariodniemision'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="DNI Emision"
        ></b-form-datepicker>

        <label class="sr-only" for="inline-form-input-username">Genero</label>
        <b-form-input v-model='newTask.usuariogenero'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Genero"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Alias</label>
        <b-form-input v-model='newTask.usuarioalias'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Alias"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Contraseña</label>
        <b-form-input v-model='newTask.usuariocontraseña'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Contraseña"
        ></b-form-input>

        <label class="sr-only" for="inline-form-input-username">Email</label>
        <b-form-input v-model='newTask.usuarioemail'
            id="inline-form-input-name"
            class="mb-2 mr-sm-2 mb-sm-0"
            placeholder="Email"
        ></b-form-input>

        <br>        
        <b-button type="submit" variant="primary">Submit</b-button>
    </b-form> 
</div>
</template>

<script>
import axios from 'axios'
export default{    
    data(){ 
        return { 
            fields: [
                
            ],            
            tasks: [],
            newTask: {},
            postURL: 'http://127.0.0.1:5000',
            config_request: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }           
        }
    },
    methods:{
        addTask(event){ 
            event.preventDefault();
            console.log("cewc");
            axios.post(this.postURL + '/create_usuario', this.newTask, this.config_request)
                .then(res => {                                         
                    this.tasks(res.data);
                    console.log(res.data)        ;
                })
                .catch((error) => {
                    console.log(error)
                });

            this.newTask = {};
        },
        deleteTask(task){  
            console.log(task);
                               
            axios.post(this.postURL + '/task/delete_task', {id:task.id}, this.config_request)
                .then(res => {                      
                    this.tasks.splice(this.tasks.indexOf(task), 1);                    
                })
                .catch((error) => {
                    console.log(error)
                });  
        }
    }

}
</script>

<style>
</style>