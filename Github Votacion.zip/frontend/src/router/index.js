import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Usuario from '@/components/Usuario'
import Vistausuario from '@/components/Vistausuario'
import Candidato from '@/components/Candidato'
import Candidatos from '@/components/Candidatos'
import Votante from '@/components/Votante'
import Votantes from '@/components/Votantes'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/usuarios',
      name: 'Usuario',
      component: Usuario
    },
    {
      path: '/verusuario',
      name: 'Vistausuario',
      component: Vistausuario
    },
    {
      path: '/candidatos',
      name: 'Candidato',
      component: Candidato
    },
    {
      path: '/vercandidato',
      name: 'Candidatos',
      component: Candidatos
    },
    {
      path: '/votantes',
      name: 'Votante',
      component: Votante
    },
    {
      path: '/vervotantes',
      name: 'Votantes',
      component: Votantes
    }
  ]
})
