<template>
  <div id="app">  
    
  <b-navbar toggleable="lg" type="dark" variant="dark">
    <b-navbar-brand href="#">Navigation</b-navbar-brand>
    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav> 
        <b-nav-item router-link to="/usuarios">Usuarios</b-nav-item>        
        <b-nav-item router-link to="/verusuario">Ver usuarios</b-nav-item>
        <b-nav-item router-link to="/candidatos">Candidatos</b-nav-item>
        <b-nav-item router-link to="/vercandidato">Ver candidatos</b-nav-item>
        <b-nav-item router-link to="/votantes">Votantes</b-nav-item>
        <b-nav-item router-link to="/vervotantes">Ver votantes</b-nav-item>
        <b-nav-item router-link to="/votos">Votos</b-nav-item>
        <b-nav-item router-link to="/vervotos">Ver votos</b-nav-item>        
      </b-navbar-nav>
      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-item-dropdown text="Lang" right>
          <b-dropdown-item href="#">EN</b-dropdown-item>
          <b-dropdown-item href="#">ES</b-dropdown-item>
          <b-dropdown-item href="#">RU</b-dropdown-item>
          <b-dropdown-item href="#">FA</b-dropdown-item>
        </b-nav-item-dropdown>
        
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
    <router-view></router-view>
    
  </div>
</template>

<script>
import Usuario from './components/Usuario'
import Vistausuario from './components/Vistausuario'
import Candidatos2 from './components/Candidatos2'
import Candidatos from './components/Candidatos'
import Votante from './components/Votante'
import Votantes from './components/Votantes'
import Voto from './components/Voto'
import VerVoto from './components/VerVoto'

export default {
  name: 'App',
  components: {
    Usuario,
    Vistausuario,
    Candidatos2,
    Candidatos,
    Votante,
    Votantes,
    Voto,
    VerVoto
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>