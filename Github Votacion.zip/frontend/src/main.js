// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import axios from 'axios'
import VueAxios from 'vue-axios'
import VuePaginate from 'vue-paginate';

import VueRouter from 'vue-router'

import {BootstrapVue, IconsPlugin} from 'bootstrap-vue'

// Import Bootstrap an BootstrapVue CSS files (order is important)
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.use(VueRouter)
Vue.use(VueAxios, axios)
Vue.use(VuePaginate);

// Make BootstrapVue available throughout your project
Vue.use(BootstrapVue)
// Optionally install the BootstrapVue icon components plugin
Vue.use(IconsPlugin)

import Usuario from './components/Usuario'
import Vistausuario from './components/Vistausuario'
import Candidatos2 from './components/Candidatos2'
import Candidatos from './components/Candidatos'
import Votante from './components/Votante'
import Votantes from './components/Votantes'
import Voto from './components/Voto'
import VerVoto from './components/VerVoto'

const router = new VueRouter({
  mode: 'history',
  base: __dirname,
  routes: [
    {
      path: '/usuarios',
      component: Usuario
    },
    {
      path: '/verusuario',
      component: Vistausuario
    },
    {
      path: '/candidatos',
      component: Candidatos2
    },
    {
      path: '/vercandidato',
      component: Candidatos
    },
    {
      path: '/votantes',
      component: Votante
    },
    {
      path: '/vervotantes',
      component: Votantes
    },
    {
      path: '/votos',
      component: Voto
    },
    {
      path: '/vervotos',
      component: VerVoto
    }


  ]
});
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
Vue.config.productionTip = false
/* eslint-disable no-new */
/*new Vue({
  el: '#app',
  components: { App },
  template: '<App/>'
})*/

new Vue({
  router: router,
  components: { App },
  template: '<App/>'
}).$mount('#app')
