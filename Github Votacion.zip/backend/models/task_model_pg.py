from backend.models.connection_pool_pg import getcursor
#from connection_pool_pg import getcursor
#from flask import jsonify
import psycopg2

conn = psycopg2.connect(
    host="127.0.0.1",
    port="8080",
    database="proyectocs",
    user="postgres",
    password="290519")

cur = conn.cursor()

class TaskModelPG:
    def create_usuario(self, usuarionombre, usuarioapellidos, usuariodni, usuariodireccion, usuarioedad, usuariofechanacimiento, usuariodniemision, usuariogenero, usuarioalias, usuariocontraseña, usuarioemail):

        params = {
            'usuarionombre': usuarionombre, 
            'usuarioapellidos': usuarioapellidos,
            'usuariodni': usuariodni, 
            'usuariodireccion': usuariodireccion, 
            'usuarioedad': usuarioedad,
            'usuariofechanacimiento': usuariofechanacimiento, 
            'usuariodniemision': usuariodniemision,
            'usuariogenero': usuariogenero, 
            'usuarioalias': usuarioalias, 
            'usuariocontraseña': usuariocontraseña,
            'usuarioemail': usuarioemail
        }

        query = """insert into usuario (usuarionombre, usuarioapellidos, usuariodni, usuariodireccion, usuarioedad, 
        usuariofechanacimiento, usuariodniemision, usuariogenero, usuarioalias, usuariocontraseña,usuarioemail)
        values (%(usuarionombre)s, %(usuarioapellidos)s, %(usuariodni)s, %(usuariodireccion)s, %(usuarioedad)s,
        %(usuariofechanacimiento)s, %(usuariodniemision)s, %(usuariogenero)s, %(usuarioalias)s, %(usuariocontraseña)s,
        %(usuarioemail)s) RETURNING id"""

        cur.execute(query, params)
        id_of_new_row = cur.fetchone()[0]
        conn.commit()
        #getcursor.con.commit()

        data = {'id': id_of_new_row, 'usuarionombre': usuarionombre, 'usuarioapellidos': usuarioapellidos,
        'usuariodni': usuariodni, 'usuariodireccion': usuariodireccion, 'usuarioedad': usuarioedad,
        'usuariofechanacimiento': usuariofechanacimiento, 'usuariodniemision': usuariodniemision,
        'usuariogenero': usuariogenero, 'usuarioalias': usuarioalias, 'usuariocontraseña': usuariocontraseña,
        'usuarioemail': usuarioemail}
        return data

    def create_candidate(self, candidatepartido, candidateocupacion, candidatesentencias):
        params = {
            'candidatepartido': candidatepartido, 
            'candidateocupacion': candidateocupacion, 
            'candidatesentencias': candidatesentencias,
            # 'vectorcandidato': vectorcandidato
        }

        query = """insert into candidato (candidatepartido, candidateocupacion, candidatesentencias) 
        values (%(candidatepartido)s, %(candidateocupacion)s,  %(candidatesentencias)s) RETURNING id"""

        cur.execute(query, params)
        id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'id': id_of_new_row, 'candidatepartido': candidatepartido,
        'candidateocupacion': candidateocupacion, 'candidatesentencias': candidatesentencias}
        return data

    def update_candidate(self, idCandidato, vectorCandidato, imagenCandidato):
        params = {
            'idCandidato': idCandidato,
            'vectorCandidato': vectorCandidato,
            'imagenCandidato': imagenCandidato
        }

        query = """update candidato set vectorcandidato = %(vectorCandidato)s, candidateimagen = %(imagenCandidato)s where 
        id = %(idCandidato)s"""

        cur.execute(query, params)
        # id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'id': idCandidato, 'vectorcandidato': vectorCandidato, 'candidateimagen': imagenCandidato}
        return data

    def create_votante(self, dnivotante, numerosala, numeromesa, numeroorden, localdevotacion):
        params = {
            'dnivotante': dnivotante,
            'numerosala': numerosala, 
            'numeromesa': numeromesa,
            'numeroorden': numeroorden, 
            'localdevotacion': localdevotacion
        }

        query = """insert into votante (dnivotante, numerosala, numeromesa, numeroorden, localdevotacion) 
        values (%(dnivotante)s, %(numerosala)s, %(numeromesa)s, %(numeroorden)s,  %(localdevotacion)s) RETURNING id"""
    
        cur.execute(query, params)
        id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'id': id_of_new_row, 'dnivotante':dnivotante, 'numerosala': numerosala, 'numeromesa': numeromesa,
        'numeroorden': numeroorden, 'localdevotacion': localdevotacion}
        return data

    def update_votante(self, dniVotante, vectorVotante, imagenVotante):
        params = {
            'dniVotante': dniVotante,
            'vectorVotante': vectorVotante,
            'imagenVotante': imagenVotante
        }

        query = """update votante set vectorvotante = %(vectorVotante)s, votantefoto = %(imagenVotante)s where 
        dnivotante = %(dniVotante)s RETURNING id"""

        cur.execute(query, params)
        # id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'dniVotante': dniVotante, 'vectorvotante': vectorVotante, 'votantefoto': imagenVotante}
        return data


    def create_voto(self, usuariovoto, partidovoto, candidatovoto, dnivoto, fechavoto, lugarvoto):
        params = {
            'usuariovoto': usuariovoto, 
            'partidovoto': partidovoto,
            'candidatovoto': candidatovoto, 
            'dnivoto': dnivoto,
            'fechavoto': fechavoto,
            'lugarvoto': lugarvoto
        }

        query = """insert into voto (usuariovoto, partidovoto, candidatovoto, dnivoto, fechavoto, lugarvoto) 
        values (%(usuariovoto)s, %(partidovoto)s, %(candidatovoto)s,  %(dnivoto)s, %(fechavoto)s, %(lugarvoto)s) RETURNING id"""
    
        cur.execute(query, params)
        id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'id': id_of_new_row, 'usuariovoto': usuariovoto, 'partidovoto': partidovoto,
        'candidatovoto': candidatovoto, 'dnivoto': dnivoto, 'fechavoto': fechavoto, 'lugarvoto': lugarvoto}
        return data

    def update_voto(self, idVoto, vectorVoto):
        params = {
            'idVoto': idVoto,
            'vectorVoto': vectorVoto
        }

        query = """update votante set vectorvoto = %(vectorVoto)s where 
        id = %(idVoto)s RETURNING id"""

        cur.execute(query, params)
        # id_of_new_row = cur.fetchone()[0]
        conn.commit()

        data = {'id': idVoto, 'vectorvoto': vectorVoto}
        return data
                 
    def usuarios(self):  
        with getcursor() as cur:
            cur.execute("SELECT * from usuario")
            #data = cursor.fetchone() # obtiene un registro
            rv = cur.fetchall()

            data = []
            content = {}
            for result in rv:
                content = {'id': result[0], 'usuarionombre': result[1], 'usuarioapellidos': result[2], 'usuariodni': result[3], 'usuariodireccion':
                result[4], 'usuarioedad': result[5], 'usuariofechanacimiento': result[6], 'usuariodniemision': result[7], 'usuariogenero': result[8],
                'usuarioalias': result[9], 'usuariocontraseña': result[10], 'usuarioemail': result[11]}
                data.append(content)
                content = {}
            return data

    def candidatos(self):
        with getcursor() as cur:
            cur.execute("SELECT * from candidato")
            #data = cursor.fetchone() # obtiene un registro
            rv = cur.fetchall()

            data = []
            content = {}
            for result in rv:
                content = {'id': result[0], 'candidatepartido': result[1], 
                'candidateocupacion': result[2], 'candidatesentencias':
                result[3]}
                data.append(content)
                content = {}
            return data

    def votantes(self):
        with getcursor() as cur:
            cur.execute("SELECT * from votante")
            #data = cursor.fetchone() # obtiene un registro
            rv = cur.fetchall()

            data = []
            content = {}
            for result in rv:
                content = {'id': result[0], 'dnivotante': result[1], 'numerosala': result[2], 'numeromesa': result[3], 
                'numeroorden': result[4], 'localdevotacion': result[5]}
                data.append(content)
                content = {}
            return data

    def voto(self):
        with getcursor() as cur:
            cur.execute("SELECT * from voto")
            #data = cursor.fetchone() # obtiene un registro
            rv = cur.fetchall()

            data = []
            content = {}
            for result in rv:
                content = {'id': result[0], 'usuariovoto': result[1], 'partidovoto': result[2], 
                'candidatovoto': result[3], 'dnivoto': result[4], 'fechavoto': result[5], 
                'lugarvoto': result[6]}
                data.append(content)
                content = {}
            return data





    
if __name__ == "__main__":    
    tm = TaskModelPG()     

    #print(tm.get_task(1))
    #print(tm.get_tasks())
    print(tm.usuarios())
    #print(tm.create_task('prueba 10', 'desde python'))